Dell info skin for Rainmeter
============================================

version 1.0.1

What is it ?
------------

A simple skin that shows the Dell icon. When you click on it it shows your
pc version and your Dell **service tab**. No more crouching under the table or
lifting dangerously your laptop to find that code. It will now be at your finger
tips.


Views
--------

There is just one view for now.


Requires
--------

This is a skin for Rainmeter, so you'll need rainmeter (and windows).

[Rainmeter official site](https://www.rainmeter.net/)


How to install it ?
-------------------

### Automatic

Double click on the file found in the bin directory. You will be invited to
install the skin.


### Manualy

Just place the whole **idefy** directory (found in src) inside your rainmeter
skins directory.
your skins directory is usualy located in:

**Windows 8/7/Vista/10**: C:\Users\YourName\Documents\Rainmeter\Skins

**Windows XP**: C:\Documents and Settings\YourName\My Documents\Rainmeter\Skins


Why did you place this on github ?
----------------------------------

I want it to be open and give others the option to propose improvements.
